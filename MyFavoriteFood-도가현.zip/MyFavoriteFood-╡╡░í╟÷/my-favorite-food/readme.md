# 피그마 링크
https://www.figma.com/file/2j1HGzgvM0oV5oMyhotY0K/My-Favorite-Food?type=design&node-id=0%3A1&mode=design&t=8xxQdMO8wWy0vDTD-1

# 텍스트 


```


My Favorite Food



Chili Hotdog
Plain food dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis

맛있습니다
와~ 놀랍네요!
굳굳




Shake Shake Burger
Shake Shake Burger dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis

빵이 부드러워요
패티 두꺼비
맛집




Superior Pizza
Garlic food dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis

라지한판
치즈가 쭈~욱


© VEAMCAMP 2023
```
